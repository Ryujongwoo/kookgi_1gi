package kr.tjoeun.memoListDB;

import java.sql.Connection;

//	Service 클래스에서 전처리 작업이 완료되서 넘어온 데이터를 가지고 sql 명령을 실행한다.
public class MemoDAO {

//	테이블에 저장할 데이터가 저장된 MemoVO 클래스 객체를 넘겨받아 테이블에 데이터를 저장하는 메소드
	public static void insert(MemoVO vo) {
		
		
		
	}

}
