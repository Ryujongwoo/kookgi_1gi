package kr.tjoeun.memoListDB;

import java.util.Scanner;

//	데이터를 테이블에 저장하기 전에 필요한 전처리 작업을 실행한다.
public class MemoService {

//	키보드로 테이블에 저장할 데이터를 입력받아 DAO 클래스로 넘겨주는 메소드
	public static void insert() {
		
//		키보드로 이름, 비밀번호, 메모를 입력받는다.
		Scanner scanner = new Scanner(System.in);
		System.out.print("이름: ");
		String name = scanner.nextLine().trim();
		System.out.print("비밀번호: ");
		String password = scanner.nextLine().trim();
		System.out.print("메모: ");
		String memo = scanner.nextLine().trim();

//		키보드로 입력받은 데이터를 MemoVO 클래스 객체를 만들어 저장한다.
		MemoVO vo = new MemoVO();
		vo.setName(name);
		vo.setPassword(password);
		vo.setMemo(memo);
		
//		키보드로 입력받은 데이터를 저장하는 DAO 클래스의 메소드를 호출한다.
		MemoDAO.insert(vo);
		
	}

}







