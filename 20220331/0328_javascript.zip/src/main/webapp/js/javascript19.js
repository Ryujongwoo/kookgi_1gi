function openWin() {
//	alert('openWin()');
//	window.open();
//	window.open(url, title, option);
	let url = './javascript_20_윈도우2.html'; // 새로 띄울 창에 표시할 페이지 이름
	let title = '아이디 중복 검사'; // 윈도우 이름
//	새 창이 브라우저에 새 탭으로 열리게 할거면 option을 생략하면 된다.
	let option = 'top=50px, left=100px, width=500px, height=600px'; // 윈도우 옵션
	window.open(url, title, option);
}

function registerForm() {
//	감춰놓은 id 속성이 register로 지정된 div 태그를 화면에 보이게 한다.
	document.getElementById('register').style.display = 'block';
}

function closeWin() {
//	id 속성이 register로 지정된 div 태그를 화면에서 사라지게 한다.
	document.getElementById('register').style.display = 'none';
}