package kr.tjoeun.generic;

//	재료 - Plastic
public class Plastic {

	@Override
	public String toString() {
		return "Plastic";
	}

}
