package kr.tjoeun.generic;

//	재료 - Powder
public class Powder {

	@Override
	public String toString() {
		return "Powder";
	}

}
