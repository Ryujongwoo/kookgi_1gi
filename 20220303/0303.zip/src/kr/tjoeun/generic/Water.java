package kr.tjoeun.generic;

//	재료 - Water
public class Water {

	@Override
	public String toString() {
		return "Water";
	}

}
