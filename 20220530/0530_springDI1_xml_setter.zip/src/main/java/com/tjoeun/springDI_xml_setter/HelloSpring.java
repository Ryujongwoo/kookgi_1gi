package com.tjoeun.springDI_xml_setter;

public class HelloSpring {

	public static void main(String[] args) {
		
		System.out.println("잠시후 2시 30분 부터 1시간 정도 취업 설명회가 있습니다.");
		
	}
	
}
