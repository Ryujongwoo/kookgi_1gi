package kr.tjoeun.bookshop;

import java.util.Date;

public class BookshopMain {

	public static void main(String[] args) {
		
//		클래스이름 객체(변수)이름 = new 생성자()
		BookVO vo = new BookVO();
		System.out.println(vo);
//		클래스로 만든 객체를 출력하면 자동으로 toString() 메소드가 실행된다.
		System.out.println(vo.toString());
		
//		도서 정보를 만든다.
//		출판일은 날짜 데이터를 만들어 BookVO 클래스의 필드에 넣어주면 다른곳에서 사용할 일이 없다.
//		이럴 경우 익명으로 객체를 만들어 사용하면 편리하다.
		BookVO book1 = new BookVO("java", "홍길동", "더조은출판사", new Date(2015, 5, 20), 35000);
		System.out.println("book1: " + book1);
		
		BookVO book2 = new BookVO("java", "홍길자", "더조은출판사", new Date(2015, 5, 20), 35000);
//		클래스에서 private으로 선언된 변수는 클래스 외부에서 접근할 수 없으므로 에러가 발생된다.
//		System.out.println(book1.title); // 에러
//		ptivate 필드에 접근하기 위해서는 getters & setters 메소드를 사용한다.
		System.out.println(book2.getTitle());
		book2.setTitle("spring");
		System.out.println(book2);
				
		BookVO book3 = new BookVO("java", "홍길도", "더조은출판사", new Date(2015, 5, 20), 35000);
		BookVO book4 = new BookVO("java", "홍길희", "더조은출판사", new Date(2015, 5, 20), 35000);
		BookVO book5 = new BookVO("java", "홍길숙", "더조은출판사", new Date(2015, 5, 20), 35000);
		
		BookVO book6 = new BookVO("java", "홍길동", "더조은출판사", new Date(2015, 5, 20), 35000);
		System.out.println("book6: " + book6);
		
//		"=="을 사용해서 같은가 비교할 수 있는 데이터는 기본 자료형 8가지와 null 만 가능하다.
//		따라서 클래스로 만든 객체는 "=="로 비교할 수 없다.
//		String은 단일 데이터가 저장되는 클래스라서 equals() 메소드만 사용하면 저장된 내용이 같은가
//		다른가 비교할 수 있었지만 String을 제외한 나머지 클래스 객체는 단일 데이터가 아니기 때문에
//		equals() 메소드만 실행해서는 같은가 다른가 비교할 수 없다.
		
		if (book1.getAuthor().equals(book6.getAuthor())) {
			System.out.println("같다");
		} else {
			System.out.println("다르다");
		}
		
//		자바에서 같은 객체로 인식하게 하려면 hashcode를 같게 만들어야 한다.
//		같은 내용을 가지는 객체인가 비교하려면 equals() 메소드가 객체에 저장된 각각의 필드값을
//		비교할 수 있게 해야한다.
//		클래스 객체에 저장된 데이터를 비교해야 한다면 hashcode() 메소드와 equals() 메소드를
//		Override 하면된다.
		
		if (book1.equals(book6)) {
			System.out.println("같다");
		} else {
			System.out.println("다르다");
		}
		
		BookList bookList = new BookList(5);
		
//		책 정보를 BookList 클래스의 bookList 배열에 저장하는 메소드를 실행한다.
		bookList.addBook(book1);
		bookList.addBook(book2);
		bookList.addBook(book3);
		bookList.addBook(book4);
		bookList.addBook(book5);
		bookList.addBook(book6);
		
		System.out.println(bookList);
		
	}
	
}




