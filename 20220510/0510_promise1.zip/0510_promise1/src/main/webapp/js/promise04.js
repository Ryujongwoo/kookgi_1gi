//	콜백 지옥

//	id와 password를 받아서 로그인 처리와 로그인 후 역할을 받아오는 클래스
class UserStorage {
	// 로그인 함수
	// loginUser(아이디, 비밀번호, 성공시 callback 함수, 실패시 callback 함수)
	loginUser(id, password, onSuccess, onError) {
		setTimeout(() => {
			if (id == '홍길동' && password == '1111' || id == '임꺽정' && password == '2222') {
				onSuccess(id);
			} else {
				onError(new Error('로그인 실패'));
			}
		}, 2000);
	}
	// 로그인 후 역할을 받아오는 함수
	// getRoles(아이디, 성공시 callback 함수, 실패시 callback 함수)
	getRoles(user, onSuccess, onError) {
		setTimeout(() => {
			if (user == '홍길동') {
				onSuccess({name: '홍길동', role: '관리자'});
			} else {
				onError(new Error('권한이 없습니다.'));
			}
		}, 1000);
	}
}


















