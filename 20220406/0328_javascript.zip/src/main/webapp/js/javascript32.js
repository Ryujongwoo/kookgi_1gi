function allSelect() {
//	name 속성이 all인 체크 박스를 체크하면 true를 해제하면 false를 변수에 저장한다.
	let check = document.getElementsByName('all')[0].checked;
	console.log(check);
	
//	name 속성이 chk인 체크 박스를 모두 얻어온다.
	let checkBoxs = document.getElementsByName('chk');
	console.log(checkBoxs);
	
//	name 속성이 chk인 체크 박스의 개수만큼 반복하며 일괄적으로 선택 또는 해제 시킨다.
	for (let checkBox of checkBoxs) {
		checkBox.checked = check;
	}
}

function chkSelect() {
	/*
//	name 속성이 chk인 체크 박스를 모두 얻어온다.
	let checkBoxs = document.getElementsByName('chk');
	console.log(checkBoxs);
	
//	빨강, 파랑, 노랑, 검정 체크 박스가 모두 체크되었나 검사한다.
	let count = 0;
	for (let checkBox of checkBoxs) {
		console.log(checkBox.checked);
		if (checkBox.checked) {
			count++;
		}
	}
	
//	빨강, 파랑, 노랑, 검정 체크 박스가 모두 체크되었으면 전체선택 체크 박스에 체크하고
//	하나라도 체크가 안되었으면 전체선택 체크 박스의 체크를 해제한다.
	if (count == checkBoxs.length) { // 모두 선택되었으면
		document.getElementsByName('all')[0].checked = true;
	} else {
		document.getElementsByName('all')[0].checked = false;
	}
	*/
	
	let checkBoxs = document.getElementsByName('chk');
	let flag = true;
	for (let checkBox of checkBoxs) {
		if (!checkBox.checked) {
			// 체크 상자가 체크가 안되어있으면 flag를 false로 변경한다.
			flag = false;
			// 빨강, 파랑, 노랑 체크 박스 중 하나라도 체크가 안되어있으면 나머지는 비교할 필요가 없다.
			break;
		}
	}
	document.getElementsByName('all')[0].checked = flag;
}

function selectColor() {
	let checkBoxs = document.getElementsByName('chk');
	for (let checkBox of checkBoxs) {
		if (checkBox.checked) {
			console.log(checkBox.value + ' 선택');
			document.getElementById(checkBox.value).style.backgroundColor = checkBox.value;
		} else {
			console.log(checkBox.value + ' 해제');
			document.getElementById(checkBox.value).style.backgroundColor = 'white';
		}
	}
}

function clearColor() {
//	let checkBoxs = document.getElementsByTagName('div');
//	for (let i=1; i<checkBoxs.length; i++) {
//		checkBoxs[i].style.backgroundColor = 'white';
//	}

	let checkBoxs = document.querySelectorAll('#colorBox > div');
	for (let checkBox of checkBoxs) {
		checkBox.style.backgroundColor = 'white';
	}
	
//	모든 체크 박스 선택을 해제하는 함수를 실행한다.
	document.getElementsByName('all')[0].checked = false;
	allSelect();
}














