function allSelect() {
//	name 속성이 all인 체크 박스를 체크하면 true를 해제하면 false를 변수에 저장한다.
	let check = document.getElementsByName('all')[0].checked;
	console.log(check);
	
//	name 속성이 chk인 체크 박스를 모두 얻어온다.
	let checkBoxs = document.getElementsByName('chk');
	console.log(checkBoxs);
	
//	name 속성이 chk인 체크 박스의 개수만큼 반복하며 일괄적으로 선택 또는 해제 시킨다.
	for (let checkBox of checkBoxs) {
		checkBox.checked = check;
	}
}

function chkSelect() {
//	name 속성이 chk인 체크 박스를 모두 얻어온다.
	let checkBoxs = document.getElementsByName('chk');
	console.log(checkBoxs);
	
//	빨강, 파랑, 노랑, 검정 체크 박스가 모두 체크되었나 검사한다.
	let count = 0;
	for (let checkBox of checkBoxs) {
		console.log(checkBox.checked);
		if (checkBox.checked) {
			count++;
		}
	}
	
//	빨강, 파랑, 노랑, 검증 체크 박스가 모두 체크되었으면 전체선택 체크 박스에 체크하고
//	하나라도 체크가 안되었으면 전체선택 체크 박스의 체크를 해제한다.
	if (count == checkBoxs.length) { // 모두 선택되었으면
		document.getElementsByName('all')[0].checked = true;
	} else {
		document.getElementsByName('all')[0].checked = false;
	}
}


















