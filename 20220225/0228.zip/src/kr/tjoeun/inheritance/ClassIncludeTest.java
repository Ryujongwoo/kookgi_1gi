package kr.tjoeun.inheritance;

import java.util.Calendar;

//	자바는 일반적으로 파일 하나에 1개의 클래스를 만들어 사용하지만 필요에 따라서 하나의 파일에 여러개의
//	클래스를 만들어 사용할 수 있다.
//	하나의 파일에 여러개의 클래스를 만들어도 컴파일된 *.class 파일은 bin 폴더에 각각 독립적으로 생성된다.
//	현재 java 파일의 이름과 같은 이름의 클래스에만 public을 붙일 수 있다.

//	기본 생성자가 실행되면 현재 날짜로 필드를 초기화하고 년, 월, 일을 넘겨받는 생성자가 실행되면
//	넘겨받은 년, 월, 일로 필드를 초기화시키는 클래스를 만든다.
class Date {
	
	private int year;
	private int month;
	private int day;
	
	public Date() {
		java.util.Date date = new java.util.Date();
		year = date.getYear() + 1900;
		month = date.getMonth() + 1;
		day = date.getDate();
	}
	public Date(int year, int month, int day) {
		this.year = year;
		this.month = month;
		this.day = day;
	}
	
	@Override
	public String toString() {
		return String.format("%04d년 %02d월 %02d일", year, month, day);
	}
	
}

//	기본 생성자가 실행되면 현재 시간으로 필드를 초기화하고 시, 분, 초를 넘겨받는 생성자가 실행되면
//	넘겨받은 시, 분, 초로 필드를 초기화시키는 클래스를 만든다.
class Time {
	
	private int hour;
	private int minute;
	private int second;
	
	public Time() {
		Calendar calendar = Calendar.getInstance();
		hour = calendar.get(Calendar.HOUR_OF_DAY);
		minute = calendar.get(Calendar.MINUTE);
		second = calendar.get(Calendar.SECOND);
	}
	public Time(int hour, int minute, int second) {
		this.hour = hour;
		this.minute = minute;
		this.second = second;
	}
	
	@Override
	public String toString() {
		return String.format("%02d:%02d:%02d", hour, minute, second);
	}
	
}

public class ClassIncludeTest {

	public static void main(String[] args) {
		
		Date date = new Date();
		System.out.println(date);
		Date date2 = new Date(2022, 7, 14);
		System.out.println(date2);
		
		Time time = new Time();
		System.out.println(time);
		Time time2 = new Time(18, 20, 1);
		System.out.println(time2);
		
		
		
	}
	
}













