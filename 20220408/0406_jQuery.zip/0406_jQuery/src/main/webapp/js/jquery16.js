$(() => {
	
	$('#shuffle').cycle({ 
	    fx:     'shuffle', 
	    easing: 'easeOutBack', 
	    delay:  -4000 
	});
	
	$('#up').cycle({ 
	    fx:    'curtainX', 
	    sync:  false, 
	    delay: -2000 
	 });
	
});

















