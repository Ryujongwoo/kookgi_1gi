//	비밀번호가 일치하는가 확인하는 함수
function passwordCheckFunction() {
	let userPassword1 = $('#userPassword1').val();
	let userPassword2 = $('#userPassword2').val();
	// console.log('userPassword1: ' + userPassword1 + ", userPassword2: " + userPassword2);
	
	if (userPassword1 != userPassword2) {
		$('#passwordCheckMessage').html('비밀번호가 일치하지 않습니다.');
	} else {
		$('#passwordCheckMessage').html('');
	}
}

//	회원 가입을 실행하는 함수
function userRegister() {
	// ajax를 이용해서 테이블에 저장할 데이터를 얻어온다.
	let userID = $('#userID').val();
	let userPassword1 = $('#userPassword1').val();
	let userPassword2 = $('#userPassword2').val();
	let userName = $('#userName').val();
	let userAge = $('#userAge').val();
	let userGender = $('input[name=userGender]:checked').val();
	let userEmail = $('#userEmail').val();
	// console.log(userID, userPassword1, userPassword2, userName, userAge, userGender, userEmail);
	
	// jQuery ajax
	$.ajax({
		type: 'POST', // 요청 방식
		url: './UserRegister', // 요청할 서블릿
		data: { // 서블릿으로 전송할 데이터
			userID: userID, 
			userPassword1: userPassword1, 
			userPassword2: userPassword2, 
			userName: userName, 
			userAge: userAge, 
			userGender: userGender, 
			userEmail: userEmail
		},
		// ajax 요청이 성공하면 response.getWriter().write(문자열)의 문자열이 콜백 함수의 인수로 전달된다.
		success: response => { // ajax 요청이 성공하면 실행할 콜백 함수
			// console.log('요청성공:', response);
		},
		// ajax 요청이 실패하면 에러 정보가 콜백 함수의 인수로 넘어온다.
		error: error => { // ajax 요청이 실패하면 실행할 콜백 함수
			console.log('요청실패:', error.status);
		}
	});
}












