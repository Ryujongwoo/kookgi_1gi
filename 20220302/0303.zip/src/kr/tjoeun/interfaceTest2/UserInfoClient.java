package kr.tjoeun.interfaceTest2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class UserInfoClient {

	public static void main(String[] args) {
		
		String dbType = "";
//		FileInputStream 클래스는 파일에서 바이트 단위로 데이터를 읽어온다.
		FileInputStream fis = null;
		
		try {
			String filepath = "./src/kr/tjoeun/interfaceTest2/db.properties";
//			FileInputStream 클래스 생성자의 인수로 읽을 파일의 경로와 이름을 넘겨주면 파일을 읽어온다.
//			FileInputStream 클래스 생성자의 인수로 파일 이름만 넘겨주면 프로젝트 이름의 폴더(0303)에서
//			파일을 읽어온다.
			fis = new FileInputStream(filepath);
			
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		
		System.out.println("dbType: " + dbType);
		
		UserInfo userInfo = new UserInfo();
		userInfo.setUserId("qwert");
		userInfo.setUserName("홍길동");
		userInfo.setUserPassword("12345");
//		System.out.println(userInfo);
		
	}
	
}
